def choose_mode():
    print('Крестики нолики / Конфеты')
    return input('Введите игру: ')


def show_results(x):
    print(f'Победил {x}')
